# SA-MP Discord Whitelist Bot

Discord.js v14 bot for written whitelist applications, staff accept/reject buttons, automatic Whitelisted role assignment, logs, and private voice interview rooms.

## Important: GitHub does not run the bot
Use GitHub on Android to store/edit this project. To keep the bot online, deploy the repository to a Node.js hosting provider that supports environment variables/secrets and a persistent worker. Never commit your real token or `.env` file.

## 1. Create the Discord application
1. Open https://discord.com/developers/applications
2. Create an application, open **Bot**, create/reset the bot token, and keep it secret.
3. In **OAuth2 > URL Generator**, select `bot` and `applications.commands`.
4. Bot permissions needed: Manage Roles, Manage Channels, View Channels, Send Messages, Embed Links, Read Message History. Use the generated invite link to add it to your server.
5. In your server, create:
   - a staff role
   - a `Whitelisted` role
   - a staff-only text channel for application review
   - a staff-only text channel for bot logs
   - a category for voice interviews
6. Put the bot's role above the `Whitelisted` role in Server Settings > Roles.

## 2. Get IDs on Android
In Discord: User Settings > Advanced > enable Developer Mode. Then long-press/right-click the server, roles, category and channels and choose **Copy ID**. For the bot Application ID, use **General Information > Application ID** in the Developer Portal.

## 3. Add the project to GitHub
1. Create a repository, e.g. `samp-whitelist-bot`.
2. Upload `index.js`, `package.json`, `.gitignore`, and `.env.example`.
3. Do not upload `.env` or your bot token.
4. On your Node.js host, connect the GitHub repository, set Node.js version 20 or newer, and set the start command to `npm start`.
5. Add every variable listed in `.env.example` in the host's Environment Variables / Secrets page, replacing each placeholder with the correct ID/token.
6. Deploy/start the service and check logs for `Ready as ...`.

## 4. Use the bot
- `/whitelist-panel` — publish the application panel in the channel where you run the command.
- Players press **تقديم طلب Whitelist**, complete the form, and the submission appears in the review channel.
- Staff press **قبول** or **رفض**. Accepting gives the `Whitelisted` role if the applicant is still in the server.
- `/interview player:@user` — staff create a private voice interview room for the selected player. After the interview, staff can manually move or delete the room from channel settings.
- `/wl-help` — show commands.

## Troubleshooting
- `Missing environment variables`: add every required variable to the hosting environment.
- `Missing Access` / `Missing Permissions`: ensure the bot can see the configured channels/category and has Manage Roles/Manage Channels. Put the bot role above `Whitelisted`.
- Commands do not appear: confirm `CLIENT_ID` and `GUILD_ID`, then restart/redeploy.
- Bot goes offline: GitHub is only source hosting; check that the Node.js worker is running on the host.
- Do not paste tokens in Discord, GitHub issues, screenshots, or chats. If a token leaks, reset it immediately in the Developer Portal.
