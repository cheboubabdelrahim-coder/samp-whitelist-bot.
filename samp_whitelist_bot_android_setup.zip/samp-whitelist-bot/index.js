require("dotenv").config();

const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  Client,
  EmbedBuilder,
  Events,
  GatewayIntentBits,
  ModalBuilder,
  PermissionFlagsBits,
  REST,
  Routes,
  SlashCommandBuilder,
  TextInputBuilder,
  TextInputStyle,
} = require("discord.js");

const required = [
  "DISCORD_TOKEN", "CLIENT_ID", "GUILD_ID", "STAFF_ROLE_ID",
  "WHITELIST_ROLE_ID", "REVIEW_CHANNEL_ID", "LOG_CHANNEL_ID",
  "INTERVIEW_CATEGORY_ID",
];
const missing = required.filter((key) => !process.env[key]);
if (missing.length) {
  console.error(`Missing environment variables: ${missing.join(", ")}`);
  process.exit(1);
}

const cfg = Object.fromEntries(required.map((key) => [key, process.env[key]]));

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

const commands = [
  new SlashCommandBuilder()
    .setName("whitelist-panel")
    .setDescription("Post the public whitelist application panel")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  new SlashCommandBuilder()
    .setName("interview")
    .setDescription("Create a private voice room for a whitelist interview")
    .addUserOption((o) => o.setName("player").setDescription("Player to interview").setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels),
  new SlashCommandBuilder()
    .setName("wl-help")
    .setDescription("Show whitelist bot setup and command help")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
].map((c) => c.toJSON());

async function registerCommands() {
  const rest = new REST({ version: "10" }).setToken(cfg.DISCORD_TOKEN);
  await rest.put(Routes.applicationGuildCommands(cfg.CLIENT_ID, cfg.GUILD_ID), { body: commands });
}

function staffOnly(interaction) {
  const roles = interaction.member?.roles;
  const hasStaffRole = Array.isArray(roles)
    ? roles.includes(cfg.STAFF_ROLE_ID)
    : Boolean(roles?.cache?.has(cfg.STAFF_ROLE_ID));
  return hasStaffRole ||
    interaction.memberPermissions?.has(PermissionFlagsBits.Administrator);
}

async function sendLog(guild, description, color = 0x5865f2) {
  const channel = await guild.channels.fetch(cfg.LOG_CHANNEL_ID).catch(() => null);
  if (!channel?.isTextBased()) return;
  const embed = new EmbedBuilder()
    .setColor(color)
    .setDescription(description)
    .setTimestamp();
  await channel.send({ embeds: [embed] }).catch(console.error);
}

client.once(Events.ClientReady, (c) => {
  console.log(`Ready as ${c.user.tag}`);
});

client.on(Events.InteractionCreate, async (interaction) => {
  try {
    if (interaction.isChatInputCommand()) {
      if (interaction.commandName === "whitelist-panel") {
        const embed = new EmbedBuilder()
          .setColor(0x5865f2)
          .setTitle("SA-MP Roleplay | Whitelist")
          .setDescription(
            "حاب تدخل للرول بلاي؟ اضغط على **تقديم طلب** وجاوب بصدق على الأسئلة.\\n" +
            "بعد مراجعة الطلب، الإدارة تقدر تستدعيك لمقابلة صوتية. ممنوع السبام أو تقديم معلومات كاذبة."
          )
          .addFields(
            { name: "المرحلة 1", value: "تقديم الطلب الكتابي", inline: true },
            { name: "المرحلة 2", value: "مراجعة الإدارة", inline: true },
            { name: "المرحلة 3", value: "مقابلة صوتية عند الحاجة", inline: true }
          )
          .setFooter({ text: "SA-MP Roleplay • Whitelist System" });
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("wl_apply").setLabel("تقديم طلب Whitelist").setStyle(ButtonStyle.Primary).setEmoji("📝")
        );
        await interaction.reply({ content: "تم نشر لوحة الوايت ليست.", ephemeral: true });
        await interaction.channel.send({ embeds: [embed], components: [row] });
        return;
      }

      if (interaction.commandName === "interview") {
        if (!staffOnly(interaction)) {
          await interaction.reply({ content: "هذا الأمر مخصص للإدارة فقط.", ephemeral: true });
          return;
        }
        await interaction.deferReply({ ephemeral: true });
        const player = interaction.options.getUser("player", true);
        const guild = interaction.guild;
        const member = await guild.members.fetch(player.id).catch(() => null);
        if (!member) {
          await interaction.editReply("اللاعب لازم يكون داخل السيرفر.");
          return;
        }
        const safeName = (player.username || "player").toLowerCase().replace(/[^a-z0-9-]/g, "-").slice(0, 18);
        const voice = await guild.channels.create({
          name: `wl-interview-${safeName}`,
          type: ChannelType.GuildVoice,
          parent: cfg.INTERVIEW_CATEGORY_ID,
          permissionOverwrites: [
            { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.Connect] },
            { id: player.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.Connect, PermissionFlagsBits.Speak] },
            { id: cfg.STAFF_ROLE_ID, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.Connect, PermissionFlagsBits.Speak, PermissionFlagsBits.ManageChannels] },
            { id: client.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.Connect, PermissionFlagsBits.ManageChannels] },
          ],
        });
        await interaction.editReply(`تم إنشاء روم المقابلة الصوتية: ${voice}`);
        await sendLog(guild, `🎙️ ${interaction.user} أنشأ مقابلة صوتية لـ ${player} في ${voice}.`);
        return;
      }

      if (interaction.commandName === "wl-help") {
        await interaction.reply({
          content: "**أوامر البوت**\\n`/whitelist-panel` نشر لوحة التقديم.\\n`/interview player:@user` إنشاء روم مقابلة خاص.\\nالقبول والرفض يتمان من رسالة الطلب في قناة المراجعة.",
          ephemeral: true,
        });
        return;
      }
    }

    if (interaction.isButton() && interaction.customId === "wl_apply") {
      const modal = new ModalBuilder().setCustomId("wl_application").setTitle("Whitelist Application");
      const fields = [
        ["rp_name", "اسمك داخل اللعبة (IC Name)", "مثال: Ahmed_Benali", 2, 40],
        ["rp_age", "عمرك", "اكتب عمرك", 1, 3],
        ["rp_definition", "اشرح معنى Roleplay", "اشرح بطريقتك", 2, 500],
        ["rp_rules", "ما معنى RDM و VDM؟", "اشرح القاعدتين", 2, 500],
        ["rp_scenario", "سيناريو: كيف تتصرف إذا أوقفك شرطي؟", "اشرح التصرف الصحيح داخل RP", 2, 700],
      ];
      modal.addComponents(...fields.map(([id, label, placeholder, style, max]) =>
        new ActionRowBuilder().addComponents(
          new TextInputBuilder()
            .setCustomId(id).setLabel(label).setPlaceholder(placeholder)
            .setStyle(style === 1 ? TextInputStyle.Short : TextInputStyle.Paragraph)
            .setRequired(true).setMaxLength(max)
        )
      ));
      await interaction.showModal(modal);
      return;
    }

    if (interaction.isModalSubmit() && interaction.customId === "wl_application") {
      await interaction.deferReply({ ephemeral: true });
      const review = await interaction.guild.channels.fetch(cfg.REVIEW_CHANNEL_ID).catch(() => null);
      if (!review?.isTextBased()) {
        await interaction.editReply("قناة مراجعة الطلبات غير مضبوطة. تواصل مع الإدارة.");
        return;
      }

      const answers = [
        ["اسم IC", interaction.fields.getTextInputValue("rp_name")],
        ["العمر", interaction.fields.getTextInputValue("rp_age")],
        ["تعريف Roleplay", interaction.fields.getTextInputValue("rp_definition")],
        ["RDM و VDM", interaction.fields.getTextInputValue("rp_rules")],
        ["سيناريو شرطي", interaction.fields.getTextInputValue("rp_scenario")],
      ];
      const embed = new EmbedBuilder()
        .setColor(0xf1c40f)
        .setTitle("طلب Whitelist جديد")
        .setDescription(`**اللاعب:** ${interaction.user} (\`${interaction.user.id}\`)\\n**الحالة:** قيد المراجعة`)
        .addFields(answers.map(([name, value]) => ({ name, value: value.slice(0, 1000) })))
        .setFooter({ text: `Applicant ID: ${interaction.user.id}` })
        .setTimestamp();

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`wl_accept:${interaction.user.id}`).setLabel("قبول").setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId(`wl_reject:${interaction.user.id}`).setLabel("رفض").setStyle(ButtonStyle.Danger)
      );
      const msg = await review.send({ embeds: [embed], components: [row] });
      await interaction.editReply("تم إرسال طلبك للإدارة. تابع رسائل السيرفر لمعرفة النتيجة.");
      await sendLog(interaction.guild, `📝 استلمنا طلب Whitelist من ${interaction.user}. رقم الرسالة: ${msg.id}`);
      return;
    }

    if (interaction.isButton() && (interaction.customId.startsWith("wl_accept:") || interaction.customId.startsWith("wl_reject:"))) {
      if (!staffOnly(interaction)) {
        await interaction.reply({ content: "هذا الزر مخصص للإدارة فقط.", ephemeral: true });
        return;
      }
      const [action, userId] = interaction.customId.split(":");
      const isAccept = action === "wl_accept";
      const applicant = await interaction.guild.members.fetch(userId).catch(() => null);

      if (isAccept && applicant) {
        const role = await interaction.guild.roles.fetch(cfg.WHITELIST_ROLE_ID).catch(() => null);
        if (!role) {
          await interaction.reply({ content: "رتبة Whitelisted غير موجودة. راجع الإعدادات.", ephemeral: true });
          return;
        }
        await applicant.roles.add(role, `Whitelist accepted by ${interaction.user.tag}`);
      }

      const oldEmbed = EmbedBuilder.from(interaction.message.embeds[0]);
      oldEmbed.setColor(isAccept ? 0x2ecc71 : 0xe74c3c);
      oldEmbed.setDescription(
        `${interaction.message.embeds[0].description}\\n\\n**القرار:** ${isAccept ? "مقبول" : "مرفوض"}\\n**بواسطة:** ${interaction.user}`
      );
      const disabledRows = interaction.message.components.map((r) =>
        new ActionRowBuilder().addComponents(r.components.map((b) => ButtonBuilder.from(b).setDisabled(true)))
      );
      await interaction.update({ embeds: [oldEmbed], components: disabledRows });
      const user = await client.users.fetch(userId).catch(() => null);
      if (user) {
        const dm = isAccept
          ? "مبروك! تم قبول طلب Whitelist تاعك. تابع تعليمات الإدارة للمقابلة الصوتية إذا كانت مطلوبة."
          : "تم رفض طلب Whitelist تاعك. تواصل مع الإدارة لمعرفة إمكانية إعادة التقديم.";
        await user.send(dm).catch(() => {});
      }
      await sendLog(interaction.guild, `${isAccept ? "✅ قبول" : "❌ رفض"} طلب اللاعب <@${userId}> بواسطة ${interaction.user}.`, isAccept ? 0x2ecc71 : 0xe74c3c);
    }
  } catch (error) {
    console.error(error);
    const message = "وقع خطأ أثناء تنفيذ العملية. راجع إعدادات البوت وسجلات الاستضافة.";
    if (interaction.isRepliable()) {
      if (interaction.deferred || interaction.replied) await interaction.followUp({ content: message, ephemeral: true }).catch(() => {});
      else await interaction.reply({ content: message, ephemeral: true }).catch(() => {});
    }
  }
});

(async () => {
  try {
    await registerCommands();
    await client.login(cfg.DISCORD_TOKEN);
  } catch (error) {
    console.error("Startup error:", error);
    process.exit(1);
  }
})();